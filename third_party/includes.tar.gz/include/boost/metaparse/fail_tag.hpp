#ifndef BOOST_METAPARSE_FAIL_TAG_HPP
#define BOOST_METAPARSE_FAIL_TAG_HPP

// Copyright Abel Sinkovics (abel@sinkovics.hu)  2013.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/metaparse/v1/fail_tag.hpp>

namespace boost
{
  namespace metaparse
  {
    using v1::fail_tag;
  }
}

#endif


